<?php
    class Logout{
        public function __construct(){}
        public function index(){
            header("Location:?c=Login");
        }
    }
?>