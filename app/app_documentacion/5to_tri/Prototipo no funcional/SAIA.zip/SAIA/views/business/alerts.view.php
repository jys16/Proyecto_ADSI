		<div class="tope"></div>
		<div class="titulo">
			<h1>Alertas</h1>
		</div>
		<div class="migas color-gris-oscuro">
			<a href="?c=Landing#portafolio">Portafolio</a>
			<p> &nbsp / &nbsp</p>
			<a href="?c=Landing&a=alerts">Alertas</a>
		</div>
		<section class="paginas">
			<h3 class="subtitulo">Plugin para Alertas con JS: SweetAlert</h3>
			<div class="sweet-alert">
				<div class="mensajeCorrecto">
					<a href="#" id="mensajeCorrecto">Enviar</a>
					<p class="parrafo">Mensaje: Correcto</p>
				</div>
				<div class="mensajeIncorrecto">
					<a href="#" id="mensajeIncorrecto">Enviar</a>
					<p class="parrafo">Mensaje: Incorrecto</p>
				</div>
				<div class="mensajeAdvertencia">
					<a href="#" id="mensajeAdvertencia-nav">
						<i id="mensajeAdvertencia-icon" class="fas fa-trash-alt"></i>
					</a>
					<p class="parrafo">Mensaje: Advertencia</p>
				</div>
			</div>
		</section>
		