		<div class="tope"></div>
		<div class="titulo">
			<h1>Reportes Gráficos</h1>
		</div>
		<div class="migas color-gris-oscuro">
			<a href="?c=Landing#nosotros">Nosotros</a>
			<p> &nbsp / &nbsp</p>
			<a href="?c=Landing&a=canvas">Reportes Gráficos</a>
		</div>
		<section class="paginas">
			<h3 class="subtitulo">Plugin para Reportes Gráficos con JS: CanvasJS</h3>
			<div class="canvas-js">
				<div class="canvas-grap">
					<div class="chart-grap" id="example1"></div>
				</div>
				<div class="canvas-grap">
					<div class="chart-grap" id="example2"></div>
				</div>
				<div class="canvas-grap">
					<div class="chart-grap" id="example3"></div>
				</div>
			</div>
		</section>
		