		<div class="tope"></div>
		<div class="titulo">
			<h1>Calendario</h1>
		</div>
		<div class="migas color-gris-oscuro">
			<a href="?c=Landing#nosotros">Nosotros</a>
			<p> &nbsp / &nbsp</p>
			<a href="?c=Landing&a=fullCalendar">Calendario</a>
		</div>
		<section class="paginas">
			<h3 class="subtitulo">Plugin para incorporar un Calendario con JS: FullCalendar</h3>
			<div class="full-calendar">
				<div id='calendar'></div>
			</div>
		</section>